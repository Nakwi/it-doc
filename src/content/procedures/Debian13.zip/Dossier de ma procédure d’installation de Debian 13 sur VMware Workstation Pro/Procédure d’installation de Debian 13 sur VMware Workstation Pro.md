# Procédure d’installation de Debian 13 sur VMware Workstation Pro

# **Sommaire :**

[Prérequis](#prérequis)

[1. Création de la machine virtuelle](#1-création-de-la-machine-virtuelle)

[2. Installation Debian](#2-installation-debian)

[3. Comptes utilisateurs](#3-comptes-utilisateurs)

[4. Partitionnement](#4-partitionnement)

[5. Paquets et logiciels](#5-paquets-et-logiciels)

[6. GRUB](#6-grub)

[7. Fin](#7-fin)

## Prérequis

* VMware Workstation Pro
* Un ISO Debian 13

## 1. Création de la machine virtuelle

* Ouvrir VMware Workstation Pro
* Créer une nouvelle machine virtuelle

![alt text](debian-01.png)

* Mode : Personnalisée (avancée)

![alt text](debian-02.png)

* Compatibilité : Workstation 25H2

![alt text](debian-03.png)

* ISO : debian-13.x-amd64-netinst.iso

![alt text](debian-04.png)

* Nom : Debian 13

![alt text](debian-05.png)

* CPU : 2 processeurs / 1 cœur

![alt text](debian-06.png)

* RAM : 2 Go

![alt text](debian-07.png)

* Réseau : NAT

![alt text](debian-08.png)

* Contrôleur : LSI Logic

![alt text](debian-09.png)

* Type de disque SCSI

![alt text](debian-10.png)

* Créer un disque virtuel

![alt text](debian-11.png)

* Disque : SCSI – 20 Go – divisé en plusieurs fichiers

![alt text](debian-12.png)

* Suivant

![alt text](debian-13.png)

* Vous pouvez mettre votre VM où vous souhaitez dans notre cas, on laisse par défaut

![alt text](debian-14.png)

# 2. Installation Debian

* Démarrer la VM
* Choisir Graphical install

![alt text](debian-15.png)

* Langue : English

![alt text](debian-16.png)

* Pays : United States

![alt text](debian-17.png)

* Clavier : French

![alt text](debian-18.png)

* Hostname : debian

![alt text](debian-19.png)

* Domaine : laisser vide

![alt text](debian-20.png)


# 3. Comptes utilisateurs

* Mot de passe root : définir

![alt text](debian-21.png)

* Nom utilisateur : dev

![alt text](debian-22.png)

* Nom utilisateur : dev

![alt text](debian-23.png)

* Mot de passe utilisateur : définir

![alt text](debian-24.png)

* Horaire du système

![alt text](debian-25.png)

---

# 4. Partitionnement

* Guided – use entire disk

![alt text](debian-26.png)

* Cliquez sur Continue

![alt text](debian-27.png)

* All files in one partition

![alt text](debian-28.png)

* Cliquez sur Continue

![alt text](debian-29.png)

* Confirmer l’écriture sur le disque

![alt text](debian-30.png)


# 5. Paquets et logiciels

* Cliquez sur Continue

![alt text](debian-31.png)

* Cliquez sur Continue

![alt text](debian-32.png)

* Miroir : deb.debian.org

![alt text](debian-33.png)

* Pas de proxy

![alt text](debian-34.png)

* Popularity contest : No

![alt text](debian-35.png)

* Sélection : GNOME, SSH server, standard utilities

![alt text](debian-36.png)

* Pour une utilisation exclusivement serveur, il est recommandé de décocher les options Debian desktop environment et GNOME, afin d’installer un système sans interface graphique, fonctionnant uniquement en ligne de commande (CLI), plus adapté et plus léger pour un usage serveur.

# 6. GRUB

* Installer GRUB : Yes

![alt text](debian-37.png)

* Disque : /dev/sda

![alt text](debian-38.png)

# 7. Fin

* Redémarrer

![alt text](debian-39.png)

* Arrivée sur le bureau GNOME Debian 13

![alt text](debian-41.png)

